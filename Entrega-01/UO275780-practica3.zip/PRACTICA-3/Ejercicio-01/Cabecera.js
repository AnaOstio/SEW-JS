var asignatura = new Object()
asignatura.nombre = "Software y Estándares en la Web";
asignatura.titulacion = "Grado en Ingeniería Informática del Software";
asignatura.centro = "Escuela de Ingeniería Informática";
asignatura.univerisdad = "Universidad de Oviedo";
asignatura.curso = "2022-2023";
asignatura.estudiante = "Ana Fernandez Ostio"
asignatura.email = "uo275780@uniovi.es"