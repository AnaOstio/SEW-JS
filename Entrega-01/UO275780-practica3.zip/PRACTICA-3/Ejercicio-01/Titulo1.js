document.write("<h1>");
document.write(asignatura.nombre);
document.write("</h1>");