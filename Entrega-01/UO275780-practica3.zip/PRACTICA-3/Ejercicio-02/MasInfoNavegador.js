document.write(infoNavegador.version);
document.write(infoNavegador.plataforma);
document.write(infoNavegador.vendedor);
document.write(infoNavegador.agente);
document.write(infoNavegador.javaActivo);